"""Simple JSON file-backed key/value storage used across the app.

Used for: cached 1-second/derived OHLC bars, the watchlist, and saved
replay sessions. Not a database - fine for a single-user local app.
"""
from pathlib import Path
import json
import os

# Default next to the backend package so cwd doesn't matter.
_DEFAULT = Path(__file__).resolve().parent.parent / "market_data"
DATA_DIR = Path(os.getenv("TR_DATA_DIR", str(_DEFAULT)))
DATA_DIR.mkdir(parents=True, exist_ok=True)


def keyfile(key: str) -> Path:
    safe = key.replace("/", "_").replace(":", "_")
    return DATA_DIR / f"{safe}.json"


def save(key: str, value):
    keyfile(key).write_text(json.dumps(value, separators=(",", ":")), encoding="utf-8")


def load(key: str, default=None):
    p = keyfile(key)
    if not p.exists():
        return [] if default is None else default
    return json.loads(p.read_text(encoding="utf-8"))
