"""Dukascopy historical tick data provider.

Dukascopy publishes free hourly tick files per symbol. Each `.bi5` file is
LZMA-compressed (NOT gzip) and holds fixed-width big-endian records:
  uint32 ms-into-hour, uint32 ask*point, uint32 bid*point, float32 ask-vol, float32 bid-vol

FX majors typically use point=1e5. Some CFD/index symbols use 1e3.
"""
from __future__ import annotations

import lzma
import struct
from datetime import date, datetime, timezone

import httpx

BASE_URL = "https://datafeed.dukascopy.com/datafeed"
RECORD_SIZE = 20  # 5 x 4-byte fields

# Symbols that need a different price scale than standard FX *1e5.
DIV_1000 = {
    "USA30IDXUSD",
    "USA500IDXUSD",
    "USATECHIDXUSD",
    "DEUIDXEUR",
    "XAUUSD",
    "XAGUSD",
    "BRENTCMDUSD",
    "LIGHTCMDUSD",
}

ALIASES = {
    "US30": "USA30IDXUSD",
    "USA30": "USA30IDXUSD",
    "DJ30": "USA30IDXUSD",
    "DJIA": "USA30IDXUSD",
    "XAUUSD": "XAUUSD",
    "GOLD": "XAUUSD",
    "BTCUSD": "BTCUSD",
    "EURUSD": "EURUSD",
}


def _normalize_symbol(symbol: str) -> str:
    sym = symbol.replace("/", "").replace(".", "").replace(" ", "").upper()
    return ALIASES.get(sym, sym)


def _point_divisor(sym: str) -> float:
    return 1000.0 if sym in DIV_1000 else 100000.0


def _decompress(content: bytes) -> bytes:
    """Try LZMA first (real Dukascopy format), then gzip as fallback."""
    if not content:
        return b""
    try:
        return lzma.decompress(content)
    except Exception:
        pass
    try:
        import gzip

        return gzip.decompress(content)
    except Exception:
        if len(content) % RECORD_SIZE == 0:
            return content
        raise


async def ticks(symbol: str, day: date, hour: int) -> list[dict]:
    sym = _normalize_symbol(symbol)
    # Dukascopy uses 0-indexed months in the URL path.
    url = (
        f"{BASE_URL}/{sym}/{day.year}/{day.month - 1:02d}/"
        f"{day.day:02d}/{hour:02d}h_ticks.bi5"
    )

    async with httpx.AsyncClient(timeout=45.0, follow_redirects=True) as client:
        resp = await client.get(url)
        if resp.status_code in (404, 204):
            return []
        if resp.status_code != 200 or not resp.content:
            return []
        try:
            raw = _decompress(resp.content)
        except Exception:
            return []

    hour_start = datetime(
        day.year, day.month, day.day, hour, tzinfo=timezone.utc
    ).timestamp()
    div = _point_divisor(sym)

    out: list[dict] = []
    for i in range(0, len(raw) - (RECORD_SIZE - 1), RECORD_SIZE):
        chunk = raw[i : i + RECORD_SIZE]
        try:
            ms, ask_i, bid_i, ask_vol, bid_vol = struct.unpack(">IIIff", chunk)
            ask = ask_i / div
            bid = bid_i / div
        except struct.error:
            ms, ask_i, bid_i, ask_vol_i, bid_vol_i = struct.unpack(">IIIII", chunk)
            ask = ask_i / div
            bid = bid_i / div
            ask_vol = float(ask_vol_i)
            bid_vol = float(bid_vol_i)
        if ask <= 0 and bid <= 0:
            continue
        out.append(
            {
                "time": hour_start + ms / 1000.0,
                "bid": bid if bid > 0 else ask,
                "ask": ask if ask > 0 else bid,
                "volume": float(ask_vol) + float(bid_vol),
            }
        )
    return out


def ticks_to_seconds(tick_list: list[dict], seconds: int = 1) -> list[dict]:
    buckets: dict[int, list] = {}
    for t in tick_list:
        bucket_key = int(t["time"] // seconds) * seconds
        mid = (t["bid"] + t["ask"]) / 2
        if bucket_key not in buckets:
            buckets[bucket_key] = [mid, mid, mid, mid, 0.0]
        else:
            b = buckets[bucket_key]
            b[1] = max(b[1], mid)
            b[2] = min(b[2], mid)
            b[3] = mid
        buckets[bucket_key][4] += t.get("volume", 0)

    return [
        {
            "time": k,
            "open": b[0],
            "high": b[1],
            "low": b[2],
            "close": b[3],
            "volume": b[4],
        }
        for k, b in sorted(buckets.items())
    ]
