from datetime import date, timedelta

from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from .aggregation import aggregate, from_1m
from .data import load, save
from .providers.dukascopy import ticks, ticks_to_seconds

app = FastAPI(title="Trading Replay Data Engine", version="3.1")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/health")
def health():
    return {"ok": True, "service": "trading-replay-data-engine", "paper_only": True}


# ---------------------------------------------------------------------------
# Bars / Data Engine
# ---------------------------------------------------------------------------

@app.get("/api/data/status")
def status(symbol: str, start: str, end: str):
    has_1s = bool(load(f"{symbol}_1s"))
    return {
        "symbol": symbol,
        "start": start,
        "end": end,
        "has_1s_cache": has_1s,
        "note": "Cache status endpoint. Downloader stores finest-resolution data.",
    }


@app.get("/api/bars")
def bars(symbol: str = "EURUSD", seconds: int = 60):
    # Never fabricate sub-minute movement from 1m bars.
    rows = load(f"{symbol}_1s")
    if seconds >= 1 and rows:
        return {"symbol": symbol, "source": "1s", "seconds": seconds, "bars": aggregate(rows, seconds)}
    if seconds >= 60:
        rows = load(f"{symbol}_60s")
        if rows:
            return {"symbol": symbol, "source": "1m", "seconds": seconds, "bars": from_1m(rows, seconds)}
    return {"symbol": symbol, "source": "unavailable", "seconds": seconds, "bars": []}


@app.post("/api/dukascopy/sync")
async def sync(symbol: str = Query(...), start: str = Query(...), end: str = Query(...)):
    d = date.fromisoformat(start)
    e = date.fromisoformat(end)
    all_ticks = []
    days = 0
    while d <= e:
        for h in range(24):
            try:
                all_ticks.extend(await ticks(symbol, d, h))
            except Exception:
                pass
        d += timedelta(days=1)
        days += 1

    one_second = ticks_to_seconds(all_ticks, 1)
    save(f"{symbol}_1s", one_second)
    return {
        "ok": True,
        "symbol": symbol,
        "start": start,
        "end": end,
        "days": days,
        "ticks": len(all_ticks),
        "seconds": len(one_second),
    }


@app.post("/api/data/aggregate")
def make_timeframe(symbol: str, seconds: int):
    one_second = load(f"{symbol}_1s")
    if not one_second:
        raise HTTPException(404, "No 1-second source data for this symbol/range.")
    rows = aggregate(one_second, seconds)
    save(f"{symbol}_{seconds}s", rows)
    return {"ok": True, "symbol": symbol, "seconds": seconds, "rows": len(rows), "source": "1s"}


@app.get("/api/data/capability")
def capability():
    return {
        "true_1s": True,
        "base_resolution": "1 second when tick source is available",
        "derived": ["2s", "5s", "10s", "15s", "30s", "60s", "120s", "180s", "300s", "900s", "1800s", "3600s", "14400s", "86400s"],
        "warning": "1m OHLC alone cannot reconstruct true within-minute movement.",
    }


# ---------------------------------------------------------------------------
# Watchlist
# ---------------------------------------------------------------------------

class WatchlistItem(BaseModel):
    symbol: str
    note: str = ""


@app.get("/api/watchlist")
def get_watchlist():
    return {"items": load("watchlist", [])}


@app.post("/api/watchlist")
def add_watchlist_item(item: WatchlistItem):
    items = load("watchlist", [])
    if not any(i["symbol"] == item.symbol for i in items):
        items.append(item.model_dump())
        save("watchlist", items)
    return {"ok": True, "items": items}


@app.delete("/api/watchlist/{symbol}")
def remove_watchlist_item(symbol: str):
    items = [i for i in load("watchlist", []) if i["symbol"] != symbol]
    save("watchlist", items)
    return {"ok": True, "items": items}


# ---------------------------------------------------------------------------
# Sessions (saved replay state)
# ---------------------------------------------------------------------------

class SessionPayload(BaseModel):
    name: str
    symbol: str
    timeframe_seconds: int
    cursor: int
    speed: float = 1.0
    notes: str = ""


@app.get("/api/sessions")
def list_sessions():
    return {"sessions": load("sessions", [])}


@app.post("/api/sessions")
def save_session(payload: SessionPayload):
    sessions = load("sessions", [])
    sessions = [s for s in sessions if s["name"] != payload.name]
    sessions.append(payload.model_dump())
    save("sessions", sessions)
    return {"ok": True, "sessions": sessions}


@app.delete("/api/sessions/{name}")
def delete_session(name: str):
    sessions = [s for s in load("sessions", []) if s["name"] != name]
    save("sessions", sessions)
    return {"ok": True, "sessions": sessions}
