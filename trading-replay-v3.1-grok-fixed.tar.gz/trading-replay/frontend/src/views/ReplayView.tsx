import { useEffect, useState } from "react";
import { Chart } from "../components/Chart";
import { fetchBars } from "../lib/api";
import { generateDemoBars, readCsvFile } from "../lib/demoData";
import { SYMBOLS, TIMEFRAMES } from "../lib/types";
import type { Bar } from "../lib/types";

export function ReplayView({ backendOnline }: { backendOnline: boolean | null }) {
  const [bars, setBars] = useState<Bar[]>(() => generateDemoBars());
  const [cursor, setCursor] = useState(800);
  const [speed, setSpeed] = useState(1);
  const [playing, setPlaying] = useState(false);
  const [symbol, setSymbol] = useState(SYMBOLS[0]);
  const [timeframeSeconds, setTimeframeSeconds] = useState(300);
  const [message, setMessage] = useState("Demo data — import a CSV or sync from the Data Engine tab");

  // Playback loop.
  useEffect(() => {
    if (!playing) return;
    const id = setInterval(() => {
      setCursor((c) => {
        if (c >= bars.length) {
          setPlaying(false);
          return c;
        }
        return c + 1;
      });
    }, 250 / speed);
    return () => clearInterval(id);
  }, [playing, speed, bars.length]);

  async function handleImport(file: File) {
    try {
      const parsed = await readCsvFile(file);
      if (parsed.length) {
        setBars(parsed);
        setCursor(Math.min(800, parsed.length));
        setMessage(`Imported ${parsed.length.toLocaleString()} bars`);
      } else {
        setMessage("No valid OHLC rows found in that file");
      }
    } catch {
      setMessage("Could not read that file");
    }
  }

  async function handleSyncedTimeframe(seconds: number) {
    setTimeframeSeconds(seconds);
    if (!backendOnline) return;
    try {
      const res = await fetchBars(symbol, seconds);
      if (res.bars.length) {
        setBars(res.bars);
        setCursor(Math.min(800, res.bars.length));
        setMessage(`Loaded ${res.bars.length.toLocaleString()} bars from backend (${res.source})`);
      } else {
        setMessage(`No cached data yet for ${symbol} — sync it from Data Engine`);
      }
    } catch {
      setMessage("Backend request failed — showing local data");
    }
  }

  const currentBar = bars[Math.max(0, cursor - 1)];

  return (
    <section className="replay-view">
      <div className="bar">
        <select value={symbol} onChange={(e) => setSymbol(e.target.value)}>
          {SYMBOLS.map((s) => (
            <option key={s} value={s}>
              {s}
            </option>
          ))}
        </select>
        {TIMEFRAMES.map((tf) => (
          <button
            key={tf.seconds}
            className={timeframeSeconds === tf.seconds ? "on" : ""}
            onClick={() => handleSyncedTimeframe(tf.seconds)}
          >
            {tf.label}
          </button>
        ))}
        <label className="import-btn">
          Import CSV
          <input
            type="file"
            accept=".csv,.txt"
            onChange={(e) => e.target.files?.[0] && handleImport(e.target.files[0])}
          />
        </label>
        <span>{message}</span>
      </div>

      <div className="chartbox">
        <Chart bars={bars} cursor={cursor} />
        <small>Source resolution: 1 second when tick data is available · Replay never exposes future bars</small>
      </div>

      <div className="replay">
        <button onClick={() => setPlaying(false)} title="Pause">
          ⏸
        </button>
        <button onClick={() => setPlaying(true)} title="Play">
          ▶
        </button>
        <button onClick={() => setCursor((c) => Math.max(20, c - 1))} title="Step back">
          |←
        </button>
        <button onClick={() => setCursor((c) => Math.min(bars.length, c + 1))} title="Step forward">
          →|
        </button>
        <select value={speed} onChange={(e) => setSpeed(Number(e.target.value))}>
          {[0.25, 0.5, 1, 2, 5, 10].map((s) => (
            <option key={s} value={s}>
              {s}×
            </option>
          ))}
        </select>
        <input
          type="range"
          min={20}
          max={bars.length}
          value={cursor}
          onChange={(e) => setCursor(Number(e.target.value))}
        />
      </div>

      <aside className="replay-info">
        <p>Current: {currentBar ? new Date(currentBar.time * 1000).toLocaleString() : "—"}</p>
        <p>Base bars: {bars.length.toLocaleString()}</p>
        <p>Target: {timeframeSeconds < 60 ? `${timeframeSeconds}s` : `${timeframeSeconds / 60}m`}</p>
      </aside>
    </section>
  );
}
