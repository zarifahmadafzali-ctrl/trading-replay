# Trading Replay v3.1

A tick-accurate trading replay PWA: React + TypeScript + Vite frontend, FastAPI backend.

## What was fixed in this rebuild

The previous zip (`trading-replay-v3-true-resolution.zip`) had four root causes
of breakage:

1. **Missing `backend/app/providers/__init__.py`.** Python couldn't import
   `providers.dukascopy` as a package, so the backend crashed on startup. Fixed.
2. **Every frontend dependency pinned to `"latest"`** in `package.json`, with no
   lockfile. A fresh install could silently pull an incompatible major version
   (this is very likely what broke it after GPT's customization). All
   dependencies are now pinned to specific, verified versions.
3. **Dev tooling (`vite`, `typescript`, `@vitejs/plugin-react`) listed under
   `dependencies`** instead of `devDependencies`, with no `@types/react` /
   `@types/react-dom`. Fixed, and type-checked.
4. **Frontend never talked to the backend.** The whole UI ran on demo data or
   CSV import only — the "Data Engine" was cosmetic. The frontend now proxies
   `/api` and `/health` to the FastAPI backend in dev, and the Data Engine view
   triggers real Dukascopy syncs.

The single 2000-character-long, unformatted `main.tsx` has also been split
into readable components and views — this is almost certainly why an AI-driven
"customization" broke something without anyone being able to see the diff.

## Project structure

```
backend/
  app/
    main.py              FastAPI app: bars, watchlist, sessions, sync
    data.py              JSON file-backed key/value store
    aggregation.py       OHLC bucket aggregation
    providers/
      dukascopy.py       Dukascopy tick data provider
  requirements.txt

frontend/
  src/
    App.tsx              View router + backend health polling
    main.tsx             Entry point
    style.css
    components/
      NavBar.tsx
      Chart.tsx           lightweight-charts v5 wrapper
    views/
      ReplayView.tsx      Chart, playback, CSV import
      WatchlistView.tsx   Backed by /api/watchlist
      SessionView.tsx     Backed by /api/sessions
      DataEngineView.tsx  Backed by /api/dukascopy/sync, /api/data/*
    lib/
      api.ts              Backend API client
      types.ts            Shared types
      demoData.ts         Demo bars + CSV parsing
  package.json
  vite.config.ts
  tsconfig.json
```

## Running it

### Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

Check it's up: `curl http://localhost:8000/health` should return
`{"ok":true,...}`.

### Frontend

In a second terminal:

```bash
cd frontend
npm install
npm run dev
```

Open the URL Vite prints (usually `http://localhost:5173`). The nav bar shows
a live "Backend online" / "Offline mode" indicator. With the backend running,
Replay, Watchlist, Session, and Data Engine are all backed by real data; with
it stopped, Replay still works from CSV import or demo data, and Watchlist/
Session fall back to browser-only state.

### Building for production

```bash
cd frontend
npm run build      # runs tsc type-check, then vite build
npm run preview    # serve the production build locally
```

For a real deployment, set `VITE_API_BASE` to your deployed backend's URL
before building, since the dev-only Vite proxy won't exist in production.

## Notes

- `lightweight-charts` is pinned to `5.2.1`. The chart code already used the
  v5 `chart.addSeries(CandlestickSeries, options)` API — pinning to v4 (as a
  naive "downgrade" fix might do) would have broken it in the other direction.
- The backend stores data as flat JSON files under `backend/market_data/` by
  default (override with the `TR_DATA_DIR` environment variable). This is
  fine for single-user local use; swap in a real database if you need
  multi-user or concurrent access.
- Dukascopy sync pulls 24 hourly tick files per day per symbol from a public,
  free feed — keep date ranges short while testing.

## Extra fixes applied after Claude's v3.1 package

1. **Dukascopy `.bi5` decompression was wrong.** Files are **LZMA**, not gzip. `gzip.decompress` always failed silently → empty ticks. Fixed in `backend/app/providers/dukascopy.py`.
2. **US30 / index price scale.** Added alias `US30` → `USA30IDXUSD` and point divisor `1e3` for index/metal CFDs.
3. **Data directory path.** `market_data` is now anchored next to the backend package so it works regardless of shell cwd.
4. **Chart volume colors** and safer scroll on update.

Run as before (two terminals). If Dukascopy returns HTTP 429, wait and retry with a short date range (1–2 days).
